package com.lnt.hr.daos;

import java.util.List;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;

public interface ScholarshipDao 
{
	public List<Scholarship> getStudList() throws ScholarshipException;
	public List<Scholarship> getMinStudList() throws ScholarshipException;
	public Scholarship getApplDetails(long applicationId) throws ScholarshipException; 
	public Scholarship setApplicationStatus(Scholarship scholarship) throws ScholarshipException;
	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException;
	
}



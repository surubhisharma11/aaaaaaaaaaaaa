package com.lnt.hr.daos;

import com.lnt.hr.entities.InsLogin;
import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;

public interface InsLoginDao 
{
	public InsLogin insertNewInstitution(InsLogin inslogin) throws LoginException;
	public int insloginCheck(InsLogin inslogin) throws LoginException;
}

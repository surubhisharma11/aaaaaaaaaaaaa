package com.lnt.hr.exception;

public class LoginException extends Exception
{



	public LoginException(String arg0) 
	{
		super(arg0);

	}

	public LoginException(String arg0, Throwable arg1) 
	{
		super(arg0, arg1);

	}

}

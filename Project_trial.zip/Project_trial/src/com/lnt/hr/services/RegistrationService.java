package com.lnt.hr.services;

import com.lnt.hr.entities.Registration;
import com.lnt.hr.exception.RegistrationException;

public interface RegistrationService 
{
	public Registration insertNewStudent(Registration registration) throws RegistrationException;

}

package com.lnt.hr.services;

import com.lnt.hr.entities.InsLogin;
import com.lnt.hr.exception.LoginException;

public interface InsLoginService 
{
	public InsLogin insertNewInstitution(InsLogin inslogin) throws LoginException;
	public int insloginCheck(InsLogin inslogin) throws LoginException;
}
